//
//  DetectionSpeed.swift
//  mobile_scanner
//
//  Created by Julian Steenbakker on 11/11/2022.
//

enum DetectionSpeed: Int {
    case noDuplicates = 0
    case normal = 1
    case unrestricted = 2
}
