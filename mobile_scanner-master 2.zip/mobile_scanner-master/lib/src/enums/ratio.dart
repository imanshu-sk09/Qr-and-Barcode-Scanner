// This enum is not used yet
// enum Ratio { ratio_4_3, ratio_16_9 }
