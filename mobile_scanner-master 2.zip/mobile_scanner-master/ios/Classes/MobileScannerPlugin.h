#import <Flutter/Flutter.h>

@interface MobileScannerPlugin : NSObject<FlutterPlugin>
@end
